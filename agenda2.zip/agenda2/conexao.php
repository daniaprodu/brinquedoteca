<?php

$servername = "localhost";
$database = "brinquedotecailda";
$username = "root";
$password = "";

$conexao = mysqli_connect($servername, $username, $password, $database );



?>